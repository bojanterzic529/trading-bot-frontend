"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

import ActionButtons from "@/components/Home/ActionButtons";
import Header from "@/components/Home/Header";
import InputForm from "@/components/Home/InputForm";
import WalletTable from "@/components/Home/WalletTable";

import { useAuth } from "@/contexts/AuthContext";
import LoadingScreen from "@/components/LoadingScreen";

export default function Home() {
  const router = useRouter();
  const { userData } = useAuth();

  const [isLoading, setLoading] = useState(true);
  const [selectedWallets, setSelectedWallets] = useState<Set<string>>(
    new Set()
  );
  const [tokenMint, setTokenMint] = useState("");
  const [adminWallet, setAdminWallet] = useState("");
  const [jitoTipAmount, setJitoTipAmount] = useState("0.0001");
  const [totalBalance, setTotalBalance] = useState({ sol: 0, token: 0 });
  const [balances, setBalances] = useState<Record<string, { sol: number; tokens: Record<string, number> }>>({});
  const [solAmounts, setSolAmounts] = useState<Record<string, number>>({});
  const [tokenAmounts, setTokenAmounts] = useState<Record<string, number>>({});

  useEffect(() => {
    if (!userData) return router.push("/login");
    setLoading(false);
  }, [userData]);

  if (isLoading) return <LoadingScreen />;
  return (
    <div className="flex py-2 justify-center items-center min-h-screen bg-background-dark text-white/65">
      <div className="w-[98%] lg:h-[98vh] flex flex-col p-4 rounded-md bg-background theme-border">
        <Header />
        <InputForm
          selectedWallets={selectedWallets}
          totalBalance={totalBalance}
          tokenMint={tokenMint}
          setTokenMint={setTokenMint}
          adminWallet={adminWallet}
          setAdminWallet={setAdminWallet}
          jitoTipAmount={jitoTipAmount}
          setJitoTipAmount={setJitoTipAmount}
          setSolAmounts={setSolAmounts}
          setTokenAmounts={setTokenAmounts}
        />
        <WalletTable
          tokenMint={tokenMint}
          selectedWallets={selectedWallets}
          setSelectedWallets={setSelectedWallets}
          setTotalBalance={setTotalBalance}
          balances={balances}
          setBalances={setBalances}
          solAmounts={solAmounts}
          tokenAmounts={tokenAmounts}
          setSolAmounts={setSolAmounts}
          setTokenAmounts={setTokenAmounts}
        />
        <ActionButtons
          tokenMint={tokenMint}
          selectedWallets={selectedWallets}
          solAmounts={solAmounts}
          tokenAmounts={tokenAmounts}
          adminWallet={adminWallet}
          jitoTipAmount={jitoTipAmount}
          setBalances={setBalances}
        />
      </div>
    </div>
  );
}

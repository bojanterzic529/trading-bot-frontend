import { useAuth } from "@/contexts/AuthContext";
import { FaSave } from "react-icons/fa";

export default function Header() {
  const { logout } = useAuth();
  return (
    <div className="flex justify-between items-center rounded-t-md">
      <h1 className="text-lg font-semibold text-white uppercase">
        PumpFun <span className="text-foreground">Bundle</span> Bot
      </h1>
      {/* <button className="text-white bg-emerald-500 p-2 rounded-md">
        <FaSave />
      </button> */}
      <button
        className="bg-background-light text-white px-4 py-2 text-sm rounded-md font-semibold flex gap-1 items-center uppercase"
        onClick={logout}>
        Sign Out
      </button>
    </div>
  );
}

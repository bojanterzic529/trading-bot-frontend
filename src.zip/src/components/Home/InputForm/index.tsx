import { useWalletContext } from "../../../contexts/WalletContext";
import { SiSolana } from "react-icons/si";
import { FaDatabase } from "react-icons/fa";
import { IoIosDownload } from "react-icons/io";
import { AiFillPlusCircle, AiFillMinusCircle } from "react-icons/ai";
import validator from "@/lib/validator";
import { useState } from "react";
import { toast } from "react-toastify";

export default function InputForm({
  selectedWallets,
  totalBalance,
  tokenMint,
  setTokenMint,
  adminWallet,
  setAdminWallet,
  jitoTipAmount,
  setJitoTipAmount,
  setSolAmounts
}: any) {

  const [showModal, setShowModal] = useState(false);

  const { wallets, generateWallets, importWallets, removeWallets, loading } = useWalletContext()

  const [exWallet, setExWallet] = useState('')

  const handleSetSolAmount = (isSame: boolean, max: number, min: number) => {
    let totalAmount = 0;
    wallets.map((wallet: any) => {
      const randomNum = Math.random() * (max - min) + min;
      const amount = isSame ? max : parseFloat(randomNum.toFixed(9))
      setSolAmounts((prevAmounts: any) => ({
        ...prevAmounts,
        [wallet.publicKey]: amount,
      }));
      totalAmount += amount;
    })

    console.log('log->totalBalance', totalAmount)
  }

  const showRemoveConfirmModal = () => {
    const [result] = validator([
      {
        value: selectedWallets,
        validatorMethod: (v: any) => Array.from(v).length > 0,
        message: "Please select wallets!"
      },
    ]);
    if (!result) return;
    setShowModal(true);
  }

  const handleRemoveWallets = () => {
    try {
      removeWallets([...selectedWallets]);
      toast.success('Removed successfully!');
    } catch (error) {
      console.log('remove wallets error', error)
      toast.error('Failed to remove wallets');
    }
    finally {
      setShowModal(false);
    }
  }

  return (
    <>
      <div className="mb-6 mt-4">
        <div className="grid grid-rows-4 lg:grid-rows-1 lg:grid-cols-4 gap-4 mb-4">
          <div>
            <label className="text-sm font-semibold uppercase">
              Token Address <span className="text-foreground">*</span>
            </label>
            <input
              type="text"
              value={tokenMint}
              onChange={(e) => setTokenMint(e.target.value)}
              placeholder="Enter Address"
              className="w-full p-2 mt-1 bg-background text-sm theme-border rounded-md outline-none"
            />
          </div>
          <div>
            <label className="text-sm font-semibold uppercase">
              Admin Wallet <span className="text-foreground">*</span>
            </label>
            <input
              type="text"
              value={adminWallet}
              onChange={(e) => setAdminWallet(e.target.value)}
              placeholder="Enter Private Key"
              className="w-full p-2 mt-1 bg-background text-sm theme-border rounded-md outline-none"
            />
          </div>
          <div>
            <label className="text-sm font-semibold uppercase">
              Import Wallet <span className="text-foreground">*</span>
            </label>
            <input
              type="text"
              value={exWallet}
              onChange={(e) => setExWallet(e.target.value)}
              placeholder="Enter Private Key"
              className="w-full p-2 mt-1 bg-background text-sm theme-border rounded-md outline-none"
            />
          </div>
          {/* <div>
            <label className="text-sm font-semibold uppercase">
              Jito Tip Amount(Sol) <span className="text-foreground">*</span>
            </label>
            <input
              type="text"
              value={jitoTipAmount}
              onChange={(e) => setJitoTipAmount(e.target.value)}
              placeholder="Enter jito tip amount"
              className="w-full p-2 mt-1 bg-background text-sm theme-border rounded-md outline-none"
            />
          </div> */}
        </div>

        <div className="flex flex-col md:flex-row justify-between md:items-center">
          <div className="flex gap-5 items-center p-2 rounded-md">
            <div className="text-sm font-semibold">
              Selected: <span className="text-white">{selectedWallets.size}</span>
            </div>
            <div className="text-sm font-semibold">
              Sol Balance: <span className="text-white">{totalBalance.sol}</span>
            </div>
            <div className="text-sm font-semibold">
              Token Balance: <span className="text-white">{totalBalance.token}</span>
            </div>
          </div>

          <div className="flex gap-4 flex-wrap items-center">
            {/* <button
            // onClick={generateWallet}
            className="bg-background-light text-white px-4 py-2 text-sm rounded-md font-semibold flex gap-1 items-center uppercase"
            disabled={loading}
          >
            <AiFillPlusCircle className="text-foreground text-lg" />
            {loading ? 'Generating...' : 'Generate Wallet'}
          </button> */}
            <button
              onClick={() => generateWallets(20)}
              className="bg-background-light text-white px-4 py-2 text-sm rounded-md font-semibold flex gap-1 items-center uppercase"
              disabled={loading}
            >
              <AiFillPlusCircle className="text-foreground text-lg" />
              {loading ? 'Generating...' : 'Generate Wallets'}
            </button>
            <button
              onClick={() => importWallets(exWallet)}
              className="bg-background-light text-white px-4 py-2 text-sm rounded-md font-semibold flex gap-1 items-center uppercase"
              disabled={loading}
            >
              <AiFillPlusCircle className="text-foreground text-lg" />
              {loading ? 'Importing...' : 'Import Wallet'}
            </button>
            <button
              onClick={showRemoveConfirmModal}
              className="bg-background-light text-white px-4 py-2 text-sm rounded-md font-semibold flex gap-1 items-center uppercase"
              disabled={loading}
            >
              <AiFillMinusCircle className="text-foreground text-lg" />
              {loading ? 'Loading...' : 'Remove Wallets'}
            </button>
            {/* <button
            // onClick={generateWallet}
            className="bg-background-light text-white px-4 py-2 text-sm rounded-md font-semibold flex gap-1 items-center uppercase"
            disabled={loading}
          >
            <IoIosDownload className="text-foreground text-lg" />
            {loading ? 'Downloading...' : 'Download Wallets'}
          </button> */}
            <button
              onClick={() => handleSetSolAmount(false, 0.05, 0.01)}
              className="bg-background-light text-white px-4 py-2 text-sm rounded-md font-semibold flex gap-1 items-center uppercase"
              disabled={loading}
            >
              <SiSolana className="text-foreground text-lg" />
              {loading ? 'Setting...' : 'Set SOL Amount'}
            </button>
            {/* <button
              onClick={() => handleSetTokenAmount(false, 0.05, 0.01)}
              className="bg-background-light text-white px-4 py-2 text-sm rounded-md font-semibold flex gap-1 items-center uppercase"
              disabled={loading}
            >
              <FaDatabase className="text-foreground text-lg" />
              {loading ? 'Setting...' : 'Set Token Amount'}
            </button> */}
          </div>
        </div>
      </div>

      {/* create & buy modal */}
      {showModal && (
        <div
          className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center"
          onClick={() => setShowModal(false)}
        >
          <div
            className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-[#10102D] rounded-lg overflow-hidden shadow-xl max-w-lg w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="bg-[#18E299] uppercase px-4 py-3 text-white text-lg font-semibold">
              Create & Buy
            </div>
            <div className="p-6">
              <p>
                Are you sure to remove the selected wallets?
              </p>
            </div>
            <div className="bg-[#10102D] px-4 py-3 flex justify-end">
              <button
                className="inline-flex justify-center rounded-sm px-4 py-2 bg-[#1A1A37] text-sm uppercase font-medium text-white"
                onClick={() => setShowModal(false)}
              >
                Cancel
              </button>
              <button
                onClick={() => handleRemoveWallets()}
                className="ml-3 inline-flex justify-center rounded-sm px-4 py-2 bg-[#18E299] text-sm uppercase font-medium text-white"
              >
                Remove
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
